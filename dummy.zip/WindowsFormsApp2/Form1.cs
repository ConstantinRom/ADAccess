﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WindowsFormsApp2.WindowsSequrityDialog;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            UserHelper.CREDUI_INFO info = new UserHelper.CREDUI_INFO();
            info.pszCaptionText = "test";
            info.pszMessageText = "Please log in:";

            UserHelper.CREDUI_FLAGS flags = UserHelper.CREDUI_FLAGS.GENERIC_CREDENTIALS |
                                            UserHelper.CREDUI_FLAGS.ALWAYS_SHOW_UI |
                                            UserHelper.CREDUI_FLAGS.DO_NOT_PERSIST |
                                            UserHelper.CREDUI_FLAGS.VALIDATE_USERNAME |
                                            UserHelper.CREDUI_FLAGS.INCORRECT_PASSWORD;
            string domain="";
            string pw="";
            string us="";
            bool save = true;

            UserHelper.PromptForCredentials(this, ref info, "test", 0, out domain, out us, out pw, ref save, flags);
             MessageBox.Show(domain + " " + us + " " + pw );
        }

    }
}

